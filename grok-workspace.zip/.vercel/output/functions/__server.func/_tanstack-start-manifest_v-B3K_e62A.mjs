//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B3K_e62A.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/rewards",
			"/trip"
		],
		preloads: ["/assets/index-DOv8Wras.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DOv8Wras.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-dTuaxR8o.js",
			"/assets/reservation-5EsZkq0x.js",
			"/assets/button-BwVhF5_Q.js"
		]
	},
	"/rewards": {
		filePath: "/workspace/src/routes/rewards.tsx",
		children: void 0,
		preloads: [
			"/assets/rewards-BrbtaeMx.js",
			"/assets/arrow-left-BhJtCrZ_.js",
			"/assets/reservation-5EsZkq0x.js"
		]
	},
	"/trip": {
		filePath: "/workspace/src/routes/trip.tsx",
		children: void 0,
		preloads: [
			"/assets/trip-C8tY-_m7.js",
			"/assets/arrow-left-BhJtCrZ_.js",
			"/assets/reservation-5EsZkq0x.js",
			"/assets/button-BwVhF5_Q.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
