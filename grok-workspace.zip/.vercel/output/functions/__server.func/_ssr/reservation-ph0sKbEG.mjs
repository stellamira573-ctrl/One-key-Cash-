import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reservation-ph0sKbEG.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatUsd(amount) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD"
	}).format(amount);
}
function KeylineMark({ className, inverted = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 40 40",
		className: cn("size-10", className),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "20",
			cy: "20",
			r: "18",
			fill: inverted ? "none" : "currentColor",
			stroke: "currentColor",
			strokeWidth: "2.2"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M14.2 11.4h4.2v6.15l5.35-6.15h5.05l-6.55 7.35 7 9.25h-5.15l-4.7-6.35-1 1.1v5.25h-4.2V11.4z",
			fill: inverted ? "currentColor" : "white"
		})]
	});
}
function KeylineWordmark({ inverted = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("flex items-center gap-2.5 font-semibold tracking-tight", inverted ? "text-paper" : "text-navy", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeylineMark, {
			inverted,
			className: "size-9 sm:size-10"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-lg sm:text-xl",
			children: "Keyline"
		})]
	});
}
function CheckoutHeader({ kicker = "Secure Checkout" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "relative overflow-hidden rounded-2xl bg-navy text-paper shadow-soft",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			className: "pointer-events-none absolute inset-y-0 right-0 h-full w-[62%] text-navy-mid",
			viewBox: "0 0 640 120",
			preserveAspectRatio: "none",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M40 120c110-8 150-78 250-86 110-8 150 52 240 44 70-6 80-42 130-46v88H40z",
				fill: "currentColor"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M120 120c90-4 130-58 220-64 100-6 140 44 230 36 50-4 60-30 90-32v60H120z",
				className: "fill-navy",
				opacity: "0.55"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative flex min-h-16 items-center gap-3 px-4 py-3 sm:min-h-[4.5rem] sm:gap-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeylineWordmark, { inverted: true }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "h-6 w-px shrink-0 bg-paper/35 sm:h-7",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-medium tracking-wide text-paper/90 sm:text-base",
					children: kicker
				})
			]
		})]
	});
}
function WaveField() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			className: "absolute -left-16 top-24 w-[42rem] text-wave/70 sm:left-0 sm:w-[48rem]",
			viewBox: "0 0 720 360",
			fill: "none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M-40 210c90-70 160-40 230-8 90 40 140-30 220-55 95-30 170 20 250 8 70-10 140-50 180-30",
				stroke: "currentColor",
				strokeWidth: "22",
				strokeLinecap: "round"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M-20 250c80-55 150-20 210 6 95 40 155-28 230-48 90-24 165 18 240 6",
				stroke: "currentColor",
				strokeWidth: "14",
				strokeLinecap: "round",
				opacity: "0.55"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			className: "absolute -right-24 bottom-[-4rem] w-[46rem] text-wave sm:right-[-2rem] sm:w-[54rem]",
			viewBox: "0 0 800 320",
			fill: "none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M20 210c90 55 170 20 250-10 95-36 150 40 240 28 100-14 170-70 290-20",
				stroke: "currentColor",
				strokeWidth: "70",
				strokeLinecap: "round",
				opacity: "0.45"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M0 250c110 40 190-10 280-28 110-22 160 48 260 32 90-14 170-58 280-8",
				stroke: "currentColor",
				strokeWidth: "36",
				strokeLinecap: "round",
				opacity: "0.7"
			})]
		})]
	});
}
function PageShell({ children, kicker, wide = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh overflow-x-hidden bg-ice text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaveField, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("relative mx-auto flex min-h-dvh flex-col px-3 pb-16 pt-3 sm:px-6 sm:pt-5", wide ? "max-w-5xl" : "max-w-3xl"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckoutHeader, { kicker }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-1 flex-col items-center pt-8 sm:pt-12",
				children
			})]
		})]
	});
}
var reservation = {
	id: "af4b76ae-3429-4011-89c3-77c4331a0349-tk2",
	guestName: "Alex Rivera",
	guestEmail: "alex.rivera@email.com",
	property: {
		name: "The Saltwater Inn",
		room: "Harbor King Suite",
		address: "14 East Battery, Charleston, SC 29401",
		neighborhood: "Historic Battery",
		image: "/images/inn.jpg",
		suiteImage: "/images/suite.jpg",
		keyImage: "/images/key.jpg"
	},
	host: {
		name: "Elena Voss",
		role: "Innkeeper & owner",
		phone: "+1 (843) 555-0142",
		email: "elena@saltwaterinn.com",
		image: "/images/host.jpg",
		responseTime: "Usually replies within 20 minutes"
	},
	stay: {
		checkInDate: "Friday, Oct 10",
		checkInTime: "4:00 PM",
		checkOutDate: "Monday, Oct 13",
		checkOutTime: "11:00 AM",
		checkInIso: "2026-10-10T16:00:00",
		checkOutIso: "2026-10-13T11:00:00",
		nights: 3,
		guests: 2,
		guestLabel: "2 adults"
	},
	payment: {
		method: "Visa",
		last4: "4242",
		subtotal: 978,
		taxes: 128.4,
		fees: 80,
		total: 1186.4,
		chargedAt: "Sep 24, 2026 · 6:12 PM"
	},
	rewards: {
		memberName: "Alex Rivera",
		currentTier: "Member",
		nextTier: "Silver",
		nightsBeforeStay: 4,
		nightsFromStay: 3,
		nightsToSilver: 10,
		cashBalance: 0
	}
};
function calendarFile() {
	const uid = `${reservation.id}@keyline.stay`;
	const dt = (iso) => iso.replace(/[-:]/g, "").replace("T", "T").slice(0, 15);
	const ics = [
		"BEGIN:VCALENDAR",
		"VERSION:2.0",
		"PRODID:-//Keyline//Reservation//EN",
		"CALSCALE:GREGORIAN",
		"BEGIN:VEVENT",
		`UID:${uid}`,
		`DTSTAMP:20260924T181200`,
		`DTSTART:${dt(reservation.stay.checkInIso)}`,
		`DTEND:${dt(reservation.stay.checkOutIso)}`,
		`SUMMARY:${reservation.property.name} · ${reservation.property.room}`,
		`LOCATION:${reservation.property.address}`,
		`DESCRIPTION:Reservation ${reservation.id}\\nHost: ${reservation.host.name} ${reservation.host.phone}`,
		"END:VEVENT",
		"END:VCALENDAR"
	].join("\r\n");
	return `data:text/calendar;charset=utf-8,${encodeURIComponent(ics)}`;
}
//#endregion
export { formatUsd as a, cn as i, PageShell as n, reservation as o, calendarFile as r, KeylineMark as t };
