import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, b as Link, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as formatUsd, i as cn, n as PageShell, o as reservation, r as calendarFile } from "./reservation-ph0sKbEG.mjs";
import { a as MapPin, c as Clock3, d as ArrowLeft, i as MessageCircle, l as CalendarPlus, n as ShieldCheck, o as Mail, r as Phone, s as Copy, u as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as buttonVariants, t as Button } from "./button-BgoGB9ww.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/trip-DGSwENt8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TripPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		kicker: "Your reservation",
		wide: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-full max-w-3xl flex-col gap-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackRow, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-5 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StayDetails, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HostCard, {})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentCard, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Policies, {})
			]
		})
	});
}
function BackRow() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: "inline-flex min-h-11 w-fit items-center gap-2 text-sm font-semibold text-navy hover:text-action",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Back to confirmation"]
	});
}
function Hero() {
	const { property, stay } = reservation;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-card bg-paper shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: property.image,
				alt: property.name,
				className: "h-52 w-full object-cover sm:h-72"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 bg-linear-to-t from-navy-deep via-navy-deep/55 to-transparent px-5 pb-4 pt-20 sm:px-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold uppercase tracking-wider text-paper/80",
					children: [
						stay.nights,
						" nights · ",
						property.neighborhood
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-extrabold text-2xl text-paper sm:text-3xl",
					children: property.name
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-px bg-line sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Check-in",
					value: stay.checkInDate,
					hint: stay.checkInTime
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Check-out",
					value: stay.checkOutDate,
					hint: stay.checkOutTime
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Room",
					value: property.room,
					hint: stay.guestLabel
				})
			]
		})]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-paper px-5 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-wider text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-semibold text-ink",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: hint
			})
		]
	});
}
function StayDetails() {
	const { property, id } = reservation;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-2xl bg-paper shadow-outline",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: property.suiteImage,
			alt: property.room,
			className: "h-44 w-full object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-bold text-lg text-ink",
					children: "Stay details"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: property.address
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3 rounded-xl bg-ice px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-4 shrink-0 text-navy" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-ink",
						children: [
							"Front desk holds a brass key for ",
							reservation.guestName,
							". Check-in is at the lobby desk — no lockbox."
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "md",
						onClick: async () => {
							try {
								await navigator.clipboard.writeText(id);
								toast.success("Reservation ID copied");
							} catch {
								toast.error("Couldn’t copy the ID");
							}
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "Copy ID"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: calendarFile(),
						download: "keyline-stay.ics",
						className: cn(buttonVariants({
							variant: "secondary",
							size: "md"
						})),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarPlus, { className: "size-4" }), "Add to calendar"]
					})]
				})
			]
		})]
	});
}
function HostCard() {
	const { host } = reservation;
	const [message, setMessage] = (0, import_react.useState)("");
	const [sent, setSent] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col rounded-2xl bg-paper p-5 shadow-outline",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-wider text-muted",
				children: "Owner contact"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: host.image,
					alt: host.name,
					className: "size-16 rounded-full object-cover outline-none"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-bold text-ink",
					children: host.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: host.role
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 flex items-center gap-2 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4 text-navy" }), host.responseTime]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `tel:${host.phone.replace(/[^\d+]/g, "")}`,
					className: cn(buttonVariants({
						variant: "secondary",
						size: "md"
					}), "justify-start"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), host.phone]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `mailto:${host.email}`,
					className: cn(buttonVariants({
						variant: "secondary",
						size: "md"
					}), "justify-start"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }), host.email]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 flex flex-col gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					if (!message.trim()) return;
					setSent(true);
					setMessage("");
					toast.success("Message sent to Elena");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "host-note",
						className: "text-sm font-medium text-ink",
						children: "Message the owner"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "host-note",
						value: message,
						onChange: (e) => setMessage(e.target.value),
						rows: 3,
						placeholder: "Arrival time, extra pillows, late check-in…",
						className: "min-h-24 w-full resize-y rounded-xl border-0 bg-ice px-3 py-2.5 text-sm text-ink shadow-outline outline-none placeholder:text-muted focus-visible:shadow-[0_0_0_2px_var(--color-action)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						size: "md",
						disabled: !message.trim(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), sent ? "Send another" : "Send message"]
					})
				]
			})
		]
	});
}
function PaymentCard() {
	const { payment } = reservation;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-paper p-5 shadow-outline sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-bold text-lg text-ink",
				children: "Payment confirmation"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"Charged to ",
					payment.method,
					" ···· ",
					payment.last4,
					" · ",
					payment.chargedAt
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5 shrink-0 text-success" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "mt-5 space-y-2 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Room · 3 nights",
					value: formatUsd(payment.subtotal)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Taxes",
					value: formatUsd(payment.taxes)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Service fee",
					value: formatUsd(payment.fees)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-t border-line pt-3 font-bold text-base text-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Total paid" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "tabular-nums",
						children: formatUsd(payment.total)
					})]
				})
			]
		})]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "tabular-nums font-medium",
			children: value
		})]
	});
}
function Policies() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-paper p-5 shadow-outline sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-bold text-lg text-ink",
				children: "Changes & cancellation"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "Free cancellation until Oct 8, 2026. After that, one night is held. Date changes can be requested until 48 hours before check-in."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/rewards",
				className: "mt-4 inline-flex min-h-11 items-center gap-1.5 text-sm font-semibold text-link hover:underline",
				children: ["See nights this stay adds to Silver", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
			})
		]
	});
}
//#endregion
export { TripPage as component };
