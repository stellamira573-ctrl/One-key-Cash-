import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageShell, o as reservation, t as KeylineMark } from "./reservation-ph0sKbEG.mjs";
import { d as ArrowLeft, u as ArrowRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rewards-D6dE4tnF.js
var import_jsx_runtime = require_jsx_runtime();
function RewardsPage() {
	const { rewards, stay, property } = reservation;
	const after = rewards.nightsBeforeStay + rewards.nightsFromStay;
	const remaining = rewards.nightsToSilver - after;
	const fill = Math.min(100, Math.round(after / rewards.nightsToSilver * 100));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		kicker: "Rewards activity",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-full max-w-xl flex-col gap-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex min-h-11 w-fit items-center gap-2 text-sm font-semibold text-navy hover:text-action",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Back to confirmation"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-card bg-paper px-6 py-8 text-center shadow-card sm:px-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto text-navy",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeylineMark, { className: "mx-auto size-14" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-xs font-semibold uppercase tracking-wider text-muted",
							children: [
								rewards.currentTier,
								" · ",
								rewards.memberName
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-extrabold text-3xl tracking-tight text-ink",
							children: "You’re closer to Silver"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mx-auto mt-3 max-w-sm text-sm leading-relaxed text-muted",
							children: [
								"Silver is where Keyline Cash starts. This stay adds ",
								rewards.nightsFromStay,
								" ",
								"nights toward the ",
								rewards.nightsToSilver,
								" you need."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto mt-7 max-w-sm text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-end justify-between text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-semibold tabular-nums text-ink",
									children: [
										after,
										" of ",
										rewards.nightsToSilver,
										" nights"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted",
									children: [remaining, " to Silver"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 h-2.5 overflow-hidden rounded-full bg-ice-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full origin-left rounded-full bg-action transition-transform duration-500",
									style: { transform: `scaleX(${fill / 100})` }
								})
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-paper p-5 shadow-outline sm:p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold text-lg text-ink",
						children: "Activity"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-4 divide-y divide-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, {
								title: `${property.name} · ${stay.nights} nights`,
								meta: `${stay.checkInDate} – ${stay.checkOutDate}`,
								value: `+${rewards.nightsFromStay} nights`,
								pending: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, {
								title: "Harbor loft weekend",
								meta: "Jun 14 – Jun 16, 2026",
								value: "+2 nights"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, {
								title: "Pine Ridge cabin",
								meta: "Mar 3 – Mar 5, 2026",
								value: "+2 nights"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, {
								title: "Joined Keyline Rewards",
								meta: "Jan 8, 2026",
								value: "Member"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex items-stretch gap-4 rounded-2xl bg-paper px-4 py-4 shadow-outline sm:px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center text-navy",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeylineMark, { className: "size-12" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "my-1 w-px shrink-0 bg-line",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm leading-relaxed text-ink",
								children: [
									"Keyline Cash balance is ",
									rewards.cashBalance.toFixed(2),
									" until Silver. Nights post after check-out."
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/trip",
								className: "mt-1.5 inline-flex min-h-11 items-center gap-1.5 text-sm font-semibold text-link hover:underline",
								children: ["Return to your trip", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
							})]
						})
					]
				})
			]
		})
	});
}
function Activity({ title, meta, value, pending }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-start justify-between gap-4 py-3 first:pt-0 last:pb-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-semibold text-ink",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: meta
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: pending ? "shrink-0 text-sm font-semibold text-action" : "shrink-0 text-sm font-semibold text-ink",
			children: value
		})]
	});
}
//#endregion
export { RewardsPage as component };
