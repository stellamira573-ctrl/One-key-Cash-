import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as cn } from "./reservation-ph0sKbEG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-BgoGB9ww.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-semibold transition-[background-color,transform,box-shadow,color] duration-150 ease-out select-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-action disabled:pointer-events-none disabled:opacity-50 active:scale-[0.96]", {
	variants: {
		variant: {
			primary: "rounded-full bg-action text-paper shadow-soft hover:bg-action-hover",
			secondary: "rounded-full bg-paper text-navy shadow-outline hover:bg-ice",
			ghost: "rounded-full text-link hover:bg-ice-2/60",
			link: "rounded-none p-0 font-semibold text-link hover:underline"
		},
		size: {
			lg: "h-12 min-h-12 px-7 text-base",
			md: "h-11 min-h-11 px-5 text-sm",
			sm: "h-10 min-h-10 px-4 text-sm",
			inline: "h-auto min-h-0 px-0 text-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "lg"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { buttonVariants as n, Button as t };
