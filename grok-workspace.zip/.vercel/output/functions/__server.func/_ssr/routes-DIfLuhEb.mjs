import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as formatUsd, i as cn, n as PageShell, o as reservation, t as KeylineMark } from "./reservation-ph0sKbEG.mjs";
import { u as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as buttonVariants } from "./button-BgoGB9ww.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DIfLuhEb.js
var import_jsx_runtime = require_jsx_runtime();
function SuccessCheck() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto grid size-20 place-items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "success-ring absolute inset-0 rounded-full bg-success-soft" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "relative grid size-12 place-items-center rounded-full bg-success text-paper",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 24 24",
					className: "size-6",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						className: "check-path",
						d: "M5.5 12.4l4.4 4.4L18.6 8",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2.6",
						strokeLinecap: "round",
						strokeLinejoin: "round"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Confirmed"
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageShell, {
		kicker: "Secure Checkout",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-full max-w-xl flex-col gap-4 sm:gap-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmationCard, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RewardsBanner, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaySnapshot, {})
			]
		})
	});
}
function ConfirmationCard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "stagger-in rounded-card bg-paper px-6 py-12 text-center shadow-card sm:px-12 sm:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuccessCheck, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-5 font-extrabold text-3xl leading-tight tracking-tight text-ink sm:text-4xl",
				children: "Your reservation is confirmed!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-auto mt-5 max-w-md text-sm leading-relaxed text-muted sm:text-base",
				children: [
					"Your reservation ID is",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "break-all font-medium text-link hover:underline",
						onClick: async () => {
							try {
								await navigator.clipboard.writeText(reservation.id);
								toast.success("Reservation ID copied");
							} catch {
								toast.error("Couldn’t copy the ID");
							}
						},
						children: reservation.id
					}),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-4 max-w-sm text-sm leading-relaxed text-muted sm:text-base",
				children: "View trip details and access owner contact information now."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/trip",
				className: cn(buttonVariants({
					variant: "primary",
					size: "lg"
				}), "mt-8 pl-8 pr-6"),
				children: ["Manage your trip", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
					className: "size-4",
					strokeWidth: 2.4
				})]
			})
		]
	});
}
function RewardsBanner() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex items-stretch gap-4 rounded-2xl bg-paper px-4 py-4 shadow-outline sm:gap-5 sm:px-5 sm:py-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center text-navy",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeylineMark, { className: "size-12" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "my-1 w-px shrink-0 bg-line",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-col justify-center py-0.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-ink",
					children: "You’re in! Your stay gets you closer to Silver where you’ll start earning Keyline Cash."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/rewards",
					className: "mt-1.5 inline-flex min-h-11 items-center gap-1.5 text-sm font-semibold text-link hover:underline",
					children: ["View my rewards activity", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
						className: "size-3.5",
						strokeWidth: 2.4
					})]
				})]
			})
		]
	});
}
function StaySnapshot() {
	const { property, stay, payment } = reservation;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "overflow-hidden rounded-2xl bg-paper shadow-outline",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid sm:grid-cols-[11rem_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: property.image,
				alt: property.name,
				className: "h-36 w-full object-cover sm:h-full"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-wider text-muted",
							children: "Upcoming stay"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-bold text-lg text-ink",
							children: property.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: property.room
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "grid grid-cols-2 gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Check-in"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold text-ink",
								children: stay.checkInDate
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Check-out"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold text-ink",
								children: stay.checkOutDate
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Guests"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold text-ink",
								children: stay.guestLabel
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Paid"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-semibold tabular-nums text-ink",
								children: formatUsd(payment.total)
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							"A receipt was sent to ",
							reservation.guestEmail,
							"."
						]
					})
				]
			})]
		})
	});
}
//#endregion
export { Home as component };
