import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { KeylineMark } from "@/components/logo";
import { PageShell } from "@/components/page-shell";
import { SuccessCheck } from "@/components/success-check";
import { buttonVariants } from "@/components/ui/button";
import { reservation } from "@/lib/reservation";
import { cn, formatUsd } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <PageShell kicker="Secure Checkout">
      <div className="flex w-full max-w-xl flex-col gap-4 sm:gap-5">
        <ConfirmationCard />
        <RewardsBanner />
        <StaySnapshot />
      </div>
    </PageShell>
  );
}

function ConfirmationCard() {
  return (
    <section className="stagger-in rounded-card bg-paper px-6 py-12 text-center shadow-card sm:px-12 sm:py-14">
      <SuccessCheck />
      <h1 className="mt-5 font-extrabold text-3xl leading-tight tracking-tight text-ink sm:text-4xl">
        Your reservation is confirmed!
      </h1>
      <p className="mx-auto mt-5 max-w-md text-sm leading-relaxed text-muted sm:text-base">
        Your reservation ID is{" "}
        <button
          type="button"
          className="break-all font-medium text-link hover:underline"
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(reservation.id);
              toast.success("Reservation ID copied");
            } catch {
              toast.error("Couldn’t copy the ID");
            }
          }}
        >
          {reservation.id}
        </button>
        .
      </p>
      <p className="mx-auto mt-4 max-w-sm text-sm leading-relaxed text-muted sm:text-base">
        View trip details and access owner contact information now.
      </p>
      <Link
        to="/trip"
        className={cn(
          buttonVariants({ variant: "primary", size: "lg" }),
          "mt-8 pl-8 pr-6",
        )}
      >
        Manage your trip
        <ArrowRight className="size-4" strokeWidth={2.4} />
      </Link>
    </section>
  );
}

function RewardsBanner() {
  return (
    <aside className="flex items-stretch gap-4 rounded-2xl bg-paper px-4 py-4 shadow-outline sm:gap-5 sm:px-5 sm:py-5">
      <div className="flex items-center text-navy">
        <KeylineMark className="size-12" />
      </div>
      <span className="my-1 w-px shrink-0 bg-line" aria-hidden="true" />
      <div className="flex min-w-0 flex-col justify-center py-0.5">
        <p className="text-sm leading-relaxed text-ink">
          You’re in! Your stay gets you closer to Silver where you’ll start
          earning Keyline Cash.
        </p>
        <Link
          to="/rewards"
          className="mt-1.5 inline-flex min-h-11 items-center gap-1.5 text-sm font-semibold text-link hover:underline"
        >
          View my rewards activity
          <ArrowRight className="size-3.5" strokeWidth={2.4} />
        </Link>
      </div>
    </aside>
  );
}

function StaySnapshot() {
  const { property, stay, payment } = reservation;
  return (
    <article className="overflow-hidden rounded-2xl bg-paper shadow-outline">
      <div className="grid sm:grid-cols-[11rem_1fr]">
        <img
          src={property.image}
          alt={property.name}
          className="h-36 w-full object-cover sm:h-full"
        />
        <div className="flex flex-col gap-3 p-4 sm:p-5">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted">
              Upcoming stay
            </p>
            <h2 className="mt-1 font-bold text-lg text-ink">{property.name}</h2>
            <p className="text-sm text-muted">{property.room}</p>
          </div>
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-muted">Check-in</dt>
              <dd className="font-semibold text-ink">{stay.checkInDate}</dd>
            </div>
            <div>
              <dt className="text-muted">Check-out</dt>
              <dd className="font-semibold text-ink">{stay.checkOutDate}</dd>
            </div>
            <div>
              <dt className="text-muted">Guests</dt>
              <dd className="font-semibold text-ink">{stay.guestLabel}</dd>
            </div>
            <div>
              <dt className="text-muted">Paid</dt>
              <dd className="font-semibold tabular-nums text-ink">
                {formatUsd(payment.total)}
              </dd>
            </div>
          </dl>
          <p className="text-xs text-muted">
            A receipt was sent to {reservation.guestEmail}.
          </p>
        </div>
      </div>
    </article>
  );
}
