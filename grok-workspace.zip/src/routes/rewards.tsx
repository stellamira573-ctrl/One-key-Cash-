import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { KeylineMark } from "@/components/logo";
import { PageShell } from "@/components/page-shell";
import { reservation } from "@/lib/reservation";

export const Route = createFileRoute("/rewards")({ component: RewardsPage });

function RewardsPage() {
  const { rewards, stay, property } = reservation;
  const after = rewards.nightsBeforeStay + rewards.nightsFromStay;
  const remaining = rewards.nightsToSilver - after;
  const fill = Math.min(100, Math.round((after / rewards.nightsToSilver) * 100));

  return (
    <PageShell kicker="Rewards activity">
      <div className="flex w-full max-w-xl flex-col gap-5">
        <Link
          to="/"
          className="inline-flex min-h-11 w-fit items-center gap-2 text-sm font-semibold text-navy hover:text-action"
        >
          <ArrowLeft className="size-4" />
          Back to confirmation
        </Link>

        <section className="rounded-card bg-paper px-6 py-8 text-center shadow-card sm:px-10">
          <div className="mx-auto text-navy">
            <KeylineMark className="mx-auto size-14" />
          </div>
          <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-muted">
            {rewards.currentTier} · {rewards.memberName}
          </p>
          <h1 className="mt-2 font-extrabold text-3xl tracking-tight text-ink">
            You’re closer to Silver
          </h1>
          <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-muted">
            Silver is where Keyline Cash starts. This stay adds {rewards.nightsFromStay}{" "}
            nights toward the {rewards.nightsToSilver} you need.
          </p>
          <div className="mx-auto mt-7 max-w-sm text-left">
            <div className="flex items-end justify-between text-sm">
              <span className="font-semibold tabular-nums text-ink">
                {after} of {rewards.nightsToSilver} nights
              </span>
              <span className="text-muted">{remaining} to Silver</span>
            </div>
            <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-ice-2">
              <div
                className="h-full origin-left rounded-full bg-action transition-transform duration-500"
                style={{ transform: `scaleX(${fill / 100})` }}
              />
            </div>
          </div>
        </section>

        <section className="rounded-2xl bg-paper p-5 shadow-outline sm:p-6">
          <h2 className="font-bold text-lg text-ink">Activity</h2>
          <ol className="mt-4 divide-y divide-line">
            <Activity
              title={`${property.name} · ${stay.nights} nights`}
              meta={`${stay.checkInDate} – ${stay.checkOutDate}`}
              value={`+${rewards.nightsFromStay} nights`}
              pending
            />
            <Activity
              title="Harbor loft weekend"
              meta="Jun 14 – Jun 16, 2026"
              value="+2 nights"
            />
            <Activity
              title="Pine Ridge cabin"
              meta="Mar 3 – Mar 5, 2026"
              value="+2 nights"
            />
            <Activity
              title="Joined Keyline Rewards"
              meta="Jan 8, 2026"
              value="Member"
            />
          </ol>
        </section>

        <section className="flex items-stretch gap-4 rounded-2xl bg-paper px-4 py-4 shadow-outline sm:px-5">
          <div className="flex items-center text-navy">
            <KeylineMark className="size-12" />
          </div>
          <span className="my-1 w-px shrink-0 bg-line" aria-hidden="true" />
          <div className="py-1">
            <p className="text-sm leading-relaxed text-ink">
              Keyline Cash balance is {rewards.cashBalance.toFixed(2)} until Silver.
              Nights post after check-out.
            </p>
            <Link
              to="/trip"
              className="mt-1.5 inline-flex min-h-11 items-center gap-1.5 text-sm font-semibold text-link hover:underline"
            >
              Return to your trip
              <ArrowRight className="size-3.5" />
            </Link>
          </div>
        </section>
      </div>
    </PageShell>
  );
}

function Activity({
  title,
  meta,
  value,
  pending,
}: {
  title: string;
  meta: string;
  value: string;
  pending?: boolean;
}) {
  return (
    <li className="flex items-start justify-between gap-4 py-3 first:pt-0 last:pb-0">
      <div>
        <p className="font-semibold text-ink">{title}</p>
        <p className="text-sm text-muted">{meta}</p>
      </div>
      <p
        className={
          pending
            ? "shrink-0 text-sm font-semibold text-action"
            : "shrink-0 text-sm font-semibold text-ink"
        }
      >
        {value}
      </p>
    </li>
  );
}
