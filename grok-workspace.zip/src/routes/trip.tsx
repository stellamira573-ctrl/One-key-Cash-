import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowLeft,
  ArrowRight,
  CalendarPlus,
  Clock3,
  Copy,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { PageShell } from "@/components/page-shell";
import { Button, buttonVariants } from "@/components/ui/button";
import { calendarFile, reservation } from "@/lib/reservation";
import { cn, formatUsd } from "@/lib/utils";

export const Route = createFileRoute("/trip")({ component: TripPage });

function TripPage() {
  return (
    <PageShell kicker="Your reservation" wide>
      <div className="flex w-full max-w-3xl flex-col gap-5">
        <BackRow />
        <Hero />
        <div className="grid gap-5 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]">
          <StayDetails />
          <HostCard />
        </div>
        <PaymentCard />
        <Policies />
      </div>
    </PageShell>
  );
}

function BackRow() {
  return (
    <Link
      to="/"
      className="inline-flex min-h-11 w-fit items-center gap-2 text-sm font-semibold text-navy hover:text-action"
    >
      <ArrowLeft className="size-4" />
      Back to confirmation
    </Link>
  );
}

function Hero() {
  const { property, stay } = reservation;
  return (
    <section className="overflow-hidden rounded-card bg-paper shadow-card">
      <div className="relative">
        <img
          src={property.image}
          alt={property.name}
          className="h-52 w-full object-cover sm:h-72"
        />
        <div className="absolute inset-x-0 bottom-0 bg-linear-to-t from-navy-deep via-navy-deep/55 to-transparent px-5 pb-4 pt-20 sm:px-7">
          <p className="text-xs font-semibold uppercase tracking-wider text-paper/80">
            {stay.nights} nights · {property.neighborhood}
          </p>
          <h1 className="font-extrabold text-2xl text-paper sm:text-3xl">
            {property.name}
          </h1>
        </div>
      </div>
      <div className="grid gap-px bg-line sm:grid-cols-3">
        <Stat label="Check-in" value={stay.checkInDate} hint={stay.checkInTime} />
        <Stat label="Check-out" value={stay.checkOutDate} hint={stay.checkOutTime} />
        <Stat label="Room" value={property.room} hint={stay.guestLabel} />
      </div>
    </section>
  );
}

function Stat({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint: string;
}) {
  return (
    <div className="bg-paper px-5 py-4">
      <p className="text-xs font-semibold uppercase tracking-wider text-muted">
        {label}
      </p>
      <p className="mt-1 font-semibold text-ink">{value}</p>
      <p className="text-sm text-muted">{hint}</p>
    </div>
  );
}

function StayDetails() {
  const { property, id } = reservation;
  return (
    <section className="overflow-hidden rounded-2xl bg-paper shadow-outline">
      <img
        src={property.suiteImage}
        alt={property.room}
        className="h-44 w-full object-cover"
      />
      <div className="flex flex-col gap-4 p-5">
        <div>
          <h2 className="font-bold text-lg text-ink">Stay details</h2>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            {property.address}
          </p>
        </div>
        <div className="flex items-start gap-3 rounded-xl bg-ice px-4 py-3">
          <MapPin className="mt-0.5 size-4 shrink-0 text-navy" />
          <p className="text-sm text-ink">
            Front desk holds a brass key for {reservation.guestName}. Check-in
            is at the lobby desk — no lockbox.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            size="md"
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(id);
                toast.success("Reservation ID copied");
              } catch {
                toast.error("Couldn’t copy the ID");
              }
            }}
          >
            <Copy className="size-4" />
            Copy ID
          </Button>
          <a
            href={calendarFile()}
            download="keyline-stay.ics"
            className={cn(buttonVariants({ variant: "secondary", size: "md" }))}
          >
            <CalendarPlus className="size-4" />
            Add to calendar
          </a>
        </div>
      </div>
    </section>
  );
}

function HostCard() {
  const { host } = reservation;
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  return (
    <section className="flex flex-col rounded-2xl bg-paper p-5 shadow-outline">
      <p className="text-xs font-semibold uppercase tracking-wider text-muted">
        Owner contact
      </p>
      <div className="mt-3 flex items-center gap-3">
        <img
          src={host.image}
          alt={host.name}
          className="size-16 rounded-full object-cover outline-none"
        />
        <div>
          <h2 className="font-bold text-ink">{host.name}</h2>
          <p className="text-sm text-muted">{host.role}</p>
        </div>
      </div>
      <p className="mt-3 flex items-center gap-2 text-sm text-muted">
        <Clock3 className="size-4 text-navy" />
        {host.responseTime}
      </p>
      <div className="mt-4 grid gap-2">
        <a
          href={`tel:${host.phone.replace(/[^\d+]/g, "")}`}
          className={cn(
            buttonVariants({ variant: "secondary", size: "md" }),
            "justify-start",
          )}
        >
          <Phone className="size-4" />
          {host.phone}
        </a>
        <a
          href={`mailto:${host.email}`}
          className={cn(
            buttonVariants({ variant: "secondary", size: "md" }),
            "justify-start",
          )}
        >
          <Mail className="size-4" />
          {host.email}
        </a>
      </div>
      <form
        className="mt-4 flex flex-col gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          if (!message.trim()) return;
          setSent(true);
          setMessage("");
          toast.success("Message sent to Elena");
        }}
      >
        <label htmlFor="host-note" className="text-sm font-medium text-ink">
          Message the owner
        </label>
        <textarea
          id="host-note"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          rows={3}
          placeholder="Arrival time, extra pillows, late check-in…"
          className="min-h-24 w-full resize-y rounded-xl border-0 bg-ice px-3 py-2.5 text-sm text-ink shadow-outline outline-none placeholder:text-muted focus-visible:shadow-[0_0_0_2px_var(--color-action)]"
        />
        <Button type="submit" size="md" disabled={!message.trim()}>
          <MessageCircle className="size-4" />
          {sent ? "Send another" : "Send message"}
        </Button>
      </form>
    </section>
  );
}

function PaymentCard() {
  const { payment } = reservation;
  return (
    <section className="rounded-2xl bg-paper p-5 shadow-outline sm:p-6">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="font-bold text-lg text-ink">Payment confirmation</h2>
          <p className="mt-1 text-sm text-muted">
            Charged to {payment.method} ···· {payment.last4} · {payment.chargedAt}
          </p>
        </div>
        <ShieldCheck className="size-5 shrink-0 text-success" />
      </div>
      <dl className="mt-5 space-y-2 text-sm">
        <Row label="Room · 3 nights" value={formatUsd(payment.subtotal)} />
        <Row label="Taxes" value={formatUsd(payment.taxes)} />
        <Row label="Service fee" value={formatUsd(payment.fees)} />
        <div className="flex items-center justify-between border-t border-line pt-3 font-bold text-base text-ink">
          <dt>Total paid</dt>
          <dd className="tabular-nums">{formatUsd(payment.total)}</dd>
        </div>
      </dl>
    </section>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-ink">
      <dt className="text-muted">{label}</dt>
      <dd className="tabular-nums font-medium">{value}</dd>
    </div>
  );
}

function Policies() {
  return (
    <section className="rounded-2xl bg-paper p-5 shadow-outline sm:p-6">
      <h2 className="font-bold text-lg text-ink">Changes & cancellation</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Free cancellation until Oct 8, 2026. After that, one night is held.
        Date changes can be requested until 48 hours before check-in.
      </p>
      <Link
        to="/rewards"
        className="mt-4 inline-flex min-h-11 items-center gap-1.5 text-sm font-semibold text-link hover:underline"
      >
        See nights this stay adds to Silver
        <ArrowRight className="size-3.5" />
      </Link>
    </section>
  );
}
