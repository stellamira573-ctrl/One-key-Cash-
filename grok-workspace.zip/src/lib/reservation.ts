export const reservation = {
  id: "af4b76ae-3429-4011-89c3-77c4331a0349-tk2",
  guestName: "Alex Rivera",
  guestEmail: "alex.rivera@email.com",
  property: {
    name: "The Saltwater Inn",
    room: "Harbor King Suite",
    address: "14 East Battery, Charleston, SC 29401",
    neighborhood: "Historic Battery",
    image: "/images/inn.jpg",
    suiteImage: "/images/suite.jpg",
    keyImage: "/images/key.jpg",
  },
  host: {
    name: "Elena Voss",
    role: "Innkeeper & owner",
    phone: "+1 (843) 555-0142",
    email: "elena@saltwaterinn.com",
    image: "/images/host.jpg",
    responseTime: "Usually replies within 20 minutes",
  },
  stay: {
    checkInDate: "Friday, Oct 10",
    checkInTime: "4:00 PM",
    checkOutDate: "Monday, Oct 13",
    checkOutTime: "11:00 AM",
    checkInIso: "2026-10-10T16:00:00",
    checkOutIso: "2026-10-13T11:00:00",
    nights: 3,
    guests: 2,
    guestLabel: "2 adults",
  },
  payment: {
    method: "Visa",
    last4: "4242",
    subtotal: 978,
    taxes: 128.4,
    fees: 80,
    total: 1186.4,
    chargedAt: "Sep 24, 2026 · 6:12 PM",
  },
  rewards: {
    memberName: "Alex Rivera",
    currentTier: "Member",
    nextTier: "Silver",
    nightsBeforeStay: 4,
    nightsFromStay: 3,
    nightsToSilver: 10,
    cashBalance: 0,
  },
} as const;

export function calendarFile() {
  const uid = `${reservation.id}@keyline.stay`;
  const dt = (iso: string) =>
    iso.replace(/[-:]/g, "").replace("T", "T").slice(0, 15);
  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Keyline//Reservation//EN",
    "CALSCALE:GREGORIAN",
    "BEGIN:VEVENT",
    `UID:${uid}`,
    `DTSTAMP:20260924T181200`,
    `DTSTART:${dt(reservation.stay.checkInIso)}`,
    `DTEND:${dt(reservation.stay.checkOutIso)}`,
    `SUMMARY:${reservation.property.name} · ${reservation.property.room}`,
    `LOCATION:${reservation.property.address}`,
    `DESCRIPTION:Reservation ${reservation.id}\\nHost: ${reservation.host.name} ${reservation.host.phone}`,
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
  return `data:text/calendar;charset=utf-8,${encodeURIComponent(ics)}`;
}
